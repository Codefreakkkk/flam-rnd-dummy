#include <jni.h>
#include <android/log.h>

extern "C"
JNIEXPORT void JNICALL
Java_com_flam_cameratest_MainActivity_nativeProcessFrame(JNIEnv *env, jobject thiz) {
    __android_log_print(ANDROID_LOG_INFO, "FlamDummy", "Pretend processing frame with OpenCV...");
}