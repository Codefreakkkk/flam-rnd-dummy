package com.flam.cameratest;

import android.app.Activity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.Surface;

public class MainActivity extends Activity {
    static {
        System.loadLibrary("native-lib");
    }

    private TextureView textureView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        textureView = new TextureView(this);
        setContentView(textureView);
        // Simulate camera feed and native processing
        nativeProcessFrame();
    }

    public native void nativeProcessFrame();
}