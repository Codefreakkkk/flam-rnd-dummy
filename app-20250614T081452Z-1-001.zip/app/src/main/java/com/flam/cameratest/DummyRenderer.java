package com.flam.cameratest;

public class DummyRenderer {
    public void renderFrame() {
        System.out.println("Pretending to render frame using OpenGL...");
    }
}